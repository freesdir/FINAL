from django.contrib import admin
from .models import User, Customer, Labourer, Interface
admin.site.register(User)
admin.site.register(Customer)
admin.site.register(Labourer)
admin.site.register(Interface)
# Register your models here.
