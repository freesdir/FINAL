from django.apps import AppConfig


class CoronaaConfig(AppConfig):
    name = 'coronaa'
